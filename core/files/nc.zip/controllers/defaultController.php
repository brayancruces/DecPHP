<?php

class defaultController extends Controller
{

	public function __construct()
	{
		parent::__construct();
	}


	public function index()
	{
		App::help();
	}

}