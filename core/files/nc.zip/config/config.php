<?php
/**
*	Decena Php Framework.
*
*	@author		Edgard Decena - edecena@gmail.com
* 	@link		http://www.gnusistemas.com
* 	@version	1.0.0
* 	@package	DecPHP
*	@license 	http://opensource.org/licenses/gpl-license.php GNU Public License
*/

/**
 * Modo de Ejecución de la App.
 */
App::setConfig('debug_mode',		TRUE);

/**
 * Generación del LOG de errores.
 */
App::setConfig('log_mode',			FALSE);

/**
 * Configuración de Directorios.
 */
App::setConfig('cache_folder',		'cache');
App::setConfig('classes_folder',	'classes');
App::setConfig('controllers_folder','controllers');
App::setConfig('data_folder',		'data');
App::setConfig('libs_folder',		'libs');
App::setConfig('models_folder',		'models');
App::setConfig('templates_folder',	'templates');
App::setConfig('views_folder',		'views');
App::setConfig('widgets_folder',	'widgets');
App::setConfig('css_folder',		'public.css');
App::setConfig('js_folder',			'public.js');
App::setConfig('log_folder',		'data.log');

/**
 * Template para las Vistas.
 */
App::setConfig('template',			'');

/**
 * Configuración Regional.
 */
App::setConfig('set_locale',		'es_VE');
App::setConfig('time_zone',			'America/Caracas');

/**
 * Autocarga de Clases.
 */
App::classAutoload();

/**
 * Configuración de Seguridad.
 */
App::setConfig('hash_key',			'****');	// NO modificar.
App::setConfig('hash_algorithm',	'sha1');

/**
 * Configuración de Session.
 */
App::setConfig('session_time',		0); // En minutos. Cero es tiempo de session indefinido.
App::setConfig('access_levels',		array('admin' => 1, 'user' => 2, 'guest' => 3));

/**
 * Configuración de la Base de Datos.
 */
App::setConfig('db_driver',			'');
App::setConfig('db_host',			'');
App::setConfig('db_port',			'');
App::setConfig('db_dbname',			'');
App::setConfig('db_user',			''); 
App::setConfig('db_pass',			'');
