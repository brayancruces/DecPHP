<?php
/**
*	Decena Php Framework.
*
*	@author		Edgard Decena - edecena@gmail.com
* 	@link		http://www.gnusistemas.com
* 	@version	1.0.0
* 	@package	DecPHP
*	@license 	http://opensource.org/licenses/gpl-license.php GNU Public License
*/

require_once '..'.DIRECTORY_SEPARATOR.'core'.DIRECTORY_SEPARATOR.'loadDecPHP.php';


App::setConfig('debug_mode', TRUE);


App::run(function(){

	App::help();
});